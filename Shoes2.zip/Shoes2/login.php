<?php
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';

$conn = mysqli_connect($dbhost, $dbuser, $dbpass);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }
  else
  {
    echo "<h3> <center></h3> </center>";
  }

  $company = $_POST["company"];
  $user = $_POST["username"];
  $pass = $_POST["password"];

  mysqli_select_db($conn,'vendors');
  $sql = "Select * from names where Username = '$user' and Password = '$pass' ";
  if($results = mysqli_query($conn,$sql))
  {
    $count = mysqli_num_rows($results);
    if ($count == 1) 
    { 
        echo "Login Successfull";
        header('location:http://localhost/Shoes/homepage.html');
    }
    else
    {
        // echo "<span <h5><center>Login Unsuccessfull</center></h5>";
        echo '<center><span style="color:#AFA;text-align:center;font-size: 35">Login Unsuccessful</span></center>';
    }
  }
  else
  {
    echo "dsds";
  }
  
?>