<?php 
$connection = mysqli_connect('localhost', 'root', '','style_toes');

?>

<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>


<!DOCTYPE html>
<html>
<head>
<style type="text/css" media="screen">
 select{
        height:10px;
        line-height:30px;
        background:#f4f4f4;
    } 

</style>
	<title>Sales</title>

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
     <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
 
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">

	<link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>

	<section id="topbar" class="d-none d-lg-block">
    <div class="container clearfix">
      <div class="contact-info float-left">
        <i class="icofont-envelope"></i><a href="mailto:contact@example.com">contact@styletoes.com</a>
        <i class="icofont-phone"></i> +91 1234567892
      </div>
      <div class="social-links float-right">
        <a href="#" class="twitter"><i class="icofont-twitter"></i></a>
        <a href="#" class="facebook"><i class="icofont-facebook"></i></a>
        <a href="#" class="instagram"><i class="icofont-instagram"></i></a>
        <a href="#" class="linkedin"><i class="icofont-linkedin"></i></i></a>
      </div>
    </div>
  </section>

   <header id="header">
    <div class="container">

      <div class="logo float-left">
        <h1 class="text-light"><a href="index.html"><span>Style Toes</span></a></h1>

      </div>

      <nav class="nav-menu float-right d-none d-lg-block">
       <ul>
          <li class="active"><a href="homepage.html">Home</a></li>
          <li><a href="inventory.php">Inventory</a></li>
          <li><a href="sales.php">Sales</a></li>
          <li><a href="try.php">New Invoice</a></li>
          <li><a href="customer.php">Customers</a></li>
          <li><a href="logout.php">Logout</a></li>
        </ul>
      </nav><!-- .nav-menu -->

    </div>
  </header>
<div class="table-responsive">
<table class="table">
<thead>
<tr class="success">
<th scope="col">Sr.No</th>
<th scope="col">Customer Name</th>
<th scope="col">Brand</th>
<th scope="col">Product Name</th>
<th scope="col">Size</th>
<th scope="col">Quantity</th>
<th scope="col">Rate</th>
<th scope="col">Total Price</th>
</tr>
</thead>
<?php
$sortBy = (isset($_POST['sortBy']) ? $_POST['sortBy'] : NULL);
 $query = 'SELECT * FROM purchase';
 if($sortBy != NULL) {
  $query .= ' ORDER BY ' . $sortBy;
 }
$result = mysqli_query($connection,$query);
		$i=1;
	while($row=mysqli_fetch_array($result))
		{
			echo "<tr>";
			echo "<td>".$i."</td>";
			echo "<td>".$row['customer_name']."</td>";
			echo "<td>".$row['brand']."</td>";
			echo "<td>".$row['product_name']."</td>";
			echo "<td>".$row['size']."</td>";
			echo "<td>".$row['quantity']."</td>";
			echo "<td>".$row['rate']."</td>";
			echo "<td>".$row['total_price']."</td>";
			echo "</tr>";
		$i++;
		}
		
	mysqli_close($connection); 
		?>

<form>
<div class="row g-3 align-items-center">
<div class="col-auto">
   <select name="sortBy" class="form-control" style="margin-left:50px" height:40px>
    <option value="brand">Brand</option>
    <option value="Customer_Name">Customer Name</option>
    <option value="product_name">Product Name</option>
    <option value="size">Size</option>
    <option value="quantity">Quantity</option>
    <option value="rate">Rate</option>
    <option value="total_price">Total Price</option>
   </select>
   
    <br>
   <button class="btn btn-secondary" type="submit" formaction="?" formmethod="post" style="margin-left:50px">Submit</button>
  </form></div></div>
  <br></br>
  <br></br>
</body>
</html>




