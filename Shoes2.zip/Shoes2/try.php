<?php

if(isset($_GET['submit'] ))
{
    echo 'hello';

$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';

$conn = mysqli_connect($dbhost, $dbuser, $dbpass);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }
  else
  {
      echo 'Connected';
  }

  $customername = $_POST["customername"];
  $phone = $_POST["phone"];
  $address1 = $_POST["address1"];
  $brand = $_POST['brand'];
  $productname = $_POST['productname'];
    $size = $_POST['size'];
    $quantity = $_POST['quantity'];
    $total = "";
    $rate = array();
  mysqli_select_db($conn,'style_toes');

  for($j=0; $j<count($productname); $j++){
    $query= "Select * from inventory where product_name = '$productname[$j]' and size = '$size[$j]'";
    $result = mysqli_query($conn,$query);
    
    while($row=mysqli_fetch_array($result)){
            array_push($rate,$row[4]);
        
    }

    }
    $sum = 0;
    $k=0;
    for($i=0; $i<count($productname); $i++)
    {
        $sum = $sum + $rate[$i]*$quantity[$i];
    }

    for($i=0; $i<count($productname); $i++)
    {
        $query = "Select quantity,product_name from inventory where product_name = '$productname[$i]' and size = '$size[$i]'";



        if($result = mysqli_query($conn,$query))
            {
                while($row = mysqli_fetch_assoc($result))
                {
                    if($row['quantity'] < $quantity[$i])
                    {
                        echo "Not Enough Stock!";
                        $k = 0;
                    }
                    else
                    {
                 
                        $row['quantity'] = $row['quantity'] - $quantity[$i];

                        $sql1 = "UPDATE purchase SET 
                        quantity = '$row[quantity]' where product_name = '$productname[$i]' and size = '$size[$i]'";
                        mysqli_query($conn,$sql1);
                            $k = 1;
                        
                    
                    }
                }
                

            }

}
}




?>




    <!DOCTYPE html>  
    <html>  
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" crossorigin="anonymous">
    <head>  
        <title>Invoice</title>  
    </head>
    <style>
        #bodd{
            margin-left:150px;
            margin-right: 150px;
            border-radius: 5px;
        }
        #tb{
            border-radius: 20px;
        }
        #rt{
            float: right;
        }
      
    </style>

    <script src="//code.jquery.com/jquery-1.12.0.min.js">  
        </script>  
        <script src="//code.jquery.com/jquery-migrate-1.2.1.min.js">  
            </script>  
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">  
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
  
            <body>
                <div id="bodd">  
                <form action="invoice3.php" method="POST">  
                    <div class="box box-primary">  
                        <div class="box-header">  
                            <h3 class="box-title">Invoice </h3>  
                        </div><hr>
                    <div class="row">
                        <div class="col">
                        <label for="customername">Name of the Customer: </label>
                        <input type="text" class="form-control" placeholder="Name of the Customer" name="customername" id="customername">
                        </div>
                        <div class="col">
                        <label for="phone">Phone Number: </label>
                        <input type="number" class="form-control" placeholder="Phone Number" name="phone" id="phone">
                        </div>
                    </div>
                    <br><br>
                    <div class="row">
                        <div class="col">
                        <label for="address1">Address 1: </label>
                        <input type="text" class="form-control" placeholder="Address Line 1" name="address1">
                        </div>
                        <div class="col">
                        <label for="address2">Address 2: </label>
                        <input type="text" class="form-control" placeholder="Address Line 2" name="address2">
                        </div>
                    </div>
                    <br><br>
                    
                    <table class="table table-bordered table-hover" id="tb">  
                        <thead>  
                            <th>No</th>
                            <th>Brand</th>  
                            <th>Product Name</th>  
                            <th>Quantity</th>  
                            <th>Size</th>  
                            <!-- <th>Discount</th>  
                            <th>Amount</th>   -->
                            <th><input type="button" value="+" id="add" class="btnbtn-primary"></th>  
                        </thead>  
                        <tbody class="detail">  
                            <tr>  
                                <td class="no">1</td>
                                <!-- <td><input type="text" class="form-control brand" name="brand[]" id="brand"></td> -->
                                <td><select name = "brand[]" id="brand" class="form-control">
                                <?php
		
                                        $db = mysqli_connect("localhost","root","","style_toes");

                                        if(!$db)
                                        {
                                            die("Connection failed: " . mysqli_connect_error());
                                        }
                                        $records = mysqli_query($db,"select DISTINCT brand from inventory");
                                        while($data = mysqli_fetch_array($records))
                                        {
                                        ?>
                                        <option value="<?php echo $data["brand"]; ?>"> <?php echo $data["brand"]; ?> </option>
                                        <?php
                                        }
                                        

                                ?>

                                </select> </td>     
                                <!-- <td><input type="text" class="form-control productname" name="productname[]" id="product"></td> -->
                                <td><select name = "productname[]" id="productname" class="form-control">
                                <?php
		
                                        $db = mysqli_connect("localhost","root","","style_toes");

                                        if(!$db)
                                        {
                                            die("Connection failed: " . mysqli_connect_error());
                                        }
                                        $records = mysqli_query($db,"select DISTINCT product_name from inventory");
                                        while($data = mysqli_fetch_array($records))
                                        {
                                        ?>
                                        <option value="<?php echo $data["product_name"]; ?>"> <?php echo $data["product_name"]; ?> </option>
                                        <?php
                                        }
                                        

                                ?>  
                                </select></td>
                                <td><input type="text" class="form-control quantity" name="quantity[]"></td>  
                                <!-- <td><input type="text" class="form-control price" name="price[]"></td>   -->
                                <!-- <td><input type="button" name="submit" value="submit" onclick="foo()">  
                                <p id="demo"></p></td> -->
                                <!-- <td><input type="text" class="form-control discount" name="discount[]"></td>   -->
                                <!-- <td><input type="text" class="form-control amount" name="amount[]"></td>   -->
                                <!-- <td><input type="text" class="form-control size" name="size[]"></td> -->
                                <td><select name = "size[]" id="size" class="form-control">
                                <?php
		
                                        $db = mysqli_connect("localhost","root","","style_toes");

                                        if(!$db)
                                        {
                                            die("Connection failed: " . mysqli_connect_error());
                                        }
                                        $records = mysqli_query($db,"select DISTINCT size from inventory");
                                        while($data = mysqli_fetch_array($records))
                                        {
                                        ?>
                                        <option value="<?php echo $data["size"]; ?>"> <?php echo $data["size"]; ?> </option>
                                        <?php
                                        }
                                        

                                ?> 

                                

                                </select></td>
                                
                                <td><a href="#" class="remove">Delete</td>  
</tr>  
</tbody>  
<tfoot>  
<th></th>  
<th></th>  
<th></th>  
<th></th>  
<th></th>  
<th style="text-align:center;" class="total">  <b></b></th>  
</tfoot>  
  
</table>
<a href="homepage.html"><button type="button" class="btn btn-secondary">Back to Home Page</button></a>

<div id="rt"><button type="submit" class="btn btn-primary">Submit</button></div>
</form>


</div>  
</body>  
</html>  
<script type="text/javascript"> 


        $(function()  
        {  
        $('#add').click(function()  
        {  
        addnewrow();  
        });  
        $('body').delegate('.remove','click',function()  
        {  
        $(this).parent().parent().remove();  
        });  
        $('body').delegate('.quantity,.price,.discount','keyup',function()  
        {  
        
        });  
        });  
        
        function addnewrow()   
        {  
        var n=($('.detail tr').length-0)+1;  
        var tr = '<tr>'+  
        '<td class="no">'+n+'</td>'+ 
        '<td><select name = "brand[]" id="brand" class="form-control"><option value = "Adidas">Adidas</option><option value = "Skechers">Skechers</option><option value = "Nike">Nike</option><option value = "Puma">Puma</option>'+ 
        '<td><select name = "productname[]" id="productname" class="form-control"><option value="Fluid Flow">Fluid Flow</option><option value="Superstar">Superstar</option><option value="Orignals">Originals</option><option value="Striker">Striker</option><option value="Pegasus">Pegasus</option><option value="Downshifter 9">Downshifter 9</option><option value="Revolution 4">Revolution 4</option><option value="Air Jordan">Air Jordan</option><option value="Trinity">Trinity</option><option value="Auriz Badminton">Auriz Badminton</option><option value="Smashers V2">Smashers V2</option><option value="Trackracer">Trackracer</option><option value="Solar Fuse">Solar Fuse</option><option value="Go Run Pure">Go Run Pure</option><option value="Dynamite">Dynamite</option><option value="Iconic">Iconic</option>                '+  
        '<td><input type="text" class="form-control quantity" name="quantity[]"></td>'+  
        // '<td><input type="button" class="form-control name="price[]" value="price" onclick="foo()"><p id="demo"></p></td>'+  
        // '<td><input type="text" class="form-control discount" name="discount[]"></td>'+  
        // '<td><input type="text" class="form-control amount" name="amount[]"></td>'+ 
        '<td><select name = "size[]" id="size" class="form-control"><option value="10">10</option><option value="9">9</option><option value="11">11</option></select></td>'+
        '<td><a href="#" class="remove">Delete</td>'+  
        '</tr>';  
        $('.detail').append(tr);   
}  
</script>