<?php
session_start();
header("Location:firstlogin.php");
?>