<?php 
$connection = mysqli_connect('localhost', 'root', '','style_toes');
?>
    <?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $brand = $_POST['brand'];
   $productname = $_POST['productname'];
   $size = $_POST['size'];
   $quantity = $_POST['quantity'];
   $customername = $_POST['customername'];
   $address1 = $_POST['address1'];
   $address2 = $_POST['address2'];
    $customerid = $_POST['cust_id'];
    $rate=array();

  for($j=0; $j<count($productname);j++){
$query= "Select * from inventory where productname = '$productname[$j]' and size = '$size[$j]'";
$result = mysqli_query($connection,$query);
while($row=mysqli_fetch_array($result)){
array_push($rate,$row['Rate']);
    }
    }
   
?>

<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>


     <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">




  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="invoice.css">
<div class="container">
   <div class="col-md-12">
      <div class="invoice">
         <div class="invoice-company text-inverse f-w-600">
            <span class="pull-right hidden-print">
            <a href="javascript:;" class="btn btn-sm btn-white m-b-10 p-l-5"><i class="fa fa-file t-plus-1 text-danger fa-fw fa-lg"></i> Export as PDF</a>
            <a href="javascript:;" onclick="window.print()" class="btn btn-sm btn-white m-b-10 p-l-5"><i class="fa fa-print t-plus-1 fa-fw fa-lg"></i> Print</a>
            </span>
            STYLO TOES, Inc
         </div>
         <div class="invoice-header">
            <div class="invoice-from">
               <small>from</small>
               <address class="m-t-5 m-b-5">
                  <strong class="text-inverse">Stylo Toes, Inc.</strong><br>
                  5C,Beverly Park<br>
                  Delhi, 400706<br>
                  Phone: (+91) 1234567892 <br>
               </address>
            </div>
            <div class="invoice-to">
               <small>to</small>
               <address class="m-t-5 m-b-5">
                  <strong class="text-inverse">
                     <?php
                     echo "$customername";
                        echo "$address1";
                        echo "$address2";
                     ?> 
                  </strong><br>
               </address>
            </div>
            <div class="invoice-date">
               <small>Invoice / February period</small>
               <div class="date text-inverse m-t-5"><script> document.write(new Date().toLocaleDateString()); </script></div>
               <div class="invoice-detail">
                 <?php
                 echo "$customerid"; 
                 ?><br>
                  Services Product
               </div>
            </div>
         </div>

         <div class="table-responsive">
<table class="table">
<thead>
<tr class="success">
<th scope="col">Sr.No</th>
<th scope="col">Product Name</th>
<th scope="col">Quantity</th>
<th scope="col">Size</th>
<th scope="col">Rate</th>
<th scope="col">Amount</th>
</tr>
</thead>
</table>
</div>
<?php


   for($i=0; $i<count($productname);i++)
      {
         echo "<tr>";
         echo "<td>".$i."</td>";
         echo "<td>".$productname[$i]."</td>";
        echo "<td>".$quantity[$i]."</td>";
        echo "<td>".$size[$i]."</td>";
        echo "<td>".$rate[$i]."</td>";
        echo "<td>".$rate[$i]. * .$quantity[$i]."</td>";
         echo "</tr>";
      }
   mysqli_close($connection); 
      ?>


            <div class="invoice-price">
               <div class="invoice-price-left">
                  <div class="invoice-price-row">
                     <div class="sub-price">
                        <small>SUBTOTAL</small>
                        <span class="text-inverse"><?php echo'$amt'?></span>
                     </div>
                  </div>
               </div>
               <div class="invoice-price-right">
                  <small>TOTAL</small> <span class="f-w-600">$4508.00</span>
               </div>
            </div>
         </div>
         <center><h2>Thank You !! Visit Again</h2></center>
         <div class="invoice-note">
            * Make all cheques payable to Style Toes<br>
            * Payment is due within 30 days<br>
            * If you have any questions concerning this invoice, mail  contact@styletoes.com
         </div>
   
         <div class="invoice-footer">
            <p class="text-center m-b-5 f-w-600">
               THANK YOU FOR YOUR BUSINESS
            </p>
            <p class="text-center">
               <span class="m-r-10"><i class="fa fa-fw fa-lg fa-phone"></i> +91 1234567892 </span>
               <span class="m-r-10"><i class="fa fa-fw fa-lg fa-envelope"></i> contact@syletoes.com</span>
            </p>
         </div>
    
      </div>
   </div>
</div>