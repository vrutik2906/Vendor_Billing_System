<?php
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';

$conn = mysqli_connect($dbhost, $dbuser, $dbpass);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }
  else
  {
    echo "<h3> <center></h3> </center>";
  }

  $company = $_POST["company"];
  $proprietor = $_POST["proprietor"];
  $user = $_POST["username"];
  $pass = $_POST["password"];

  mysqli_select_db($conn,'vendors');
  $sql = "INSERT INTO names (company_name, proprietor, username, password) 
  VALUES ('$company', '$proprietor', '$user','$pass')";
  if($results = mysqli_query($conn,$sql))
  {
    $count = mysqli_num_rows($results);
    if ($count == 1) 
    { 
        echo "Registration Successful";
        header('location:http://localhost/hackerbash/firstlogin.php');
    }
    else
    {
        echo "Login Unsuccessful";
    }
  }
  else
  [
    echo "sfa";
  ]
 
  
?>