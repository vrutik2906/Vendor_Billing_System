<?php
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';

$conn = mysqli_connect($dbhost, $dbuser, $dbpass);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }
  else
  {
  }

  $customername = $_POST["customername"];
  $phone = $_POST["phone"];
  $address1 = $_POST["address1"];
  $brand = $_POST['brand'];
  $productname = $_POST['productname'];
    $size = $_POST['size'];
    $quantity = $_POST['quantity'];
    $total = "";
    $rate = array();
  mysqli_select_db($conn,'style_toes');

  for($j=0; $j<count($productname); $j++){
    $query= "Select * from inventory where product_name = '$productname[$j]' and size = '$size[$j]'";
    $result = mysqli_query($conn,$query);
    
    while($row=mysqli_fetch_array($result)){
            array_push($rate,$row[4]);
        
    }

    }
    $sum = 0;
    $k=0;
    for($i=0; $i<count($productname); $i++)
    {
        $sum = $sum + $rate[$i]*$quantity[$i];
    }

    for($i=0; $i<count($productname); $i++)
    {
        $query = "Select quantity,product_name from inventory where product_name = '$productname[$i]' and size = '$size[$i]'";



        if($result = mysqli_query($conn,$query))
            {
                while($row = mysqli_fetch_assoc($result))
                {
                    if($row['quantity'] < $quantity[$i])
                    {
                        echo "Not Enough Stock!";
                        $k = 0;
                    }
                    else
                    {
                 
                        $row['quantity'] = $row['quantity'] - $quantity[$i];

                        $sql1 = "UPDATE purchase SET 
                        quantity = '$row[quantity]' where product_name = '$productname[$i]' and size = '$size[$i]'";
                        mysqli_query($conn,$sql1);
                            $k = 1;
                        
                    
                    }
                }
                

            }

}

    if($k == 1){

     mysqli_select_db($conn,'style_toes');
        $brand=implode(",",$brand);
        $productname=implode(",",$productname);
        $size=implode(",",$size);
        $quantity=implode(",",$quantity);
        $rate=implode(",",$rate);

        $sql="INSERT INTO purchase 
    values('','$customername','$brand','$productname','$size','$quantity','$rate','$sum') ";
        mysqli_query($conn,$sql);
     
        // header("location:http://localhost/hackerbash/invoice3.php?customername=" .$_POST['customername']. "&address1=" .$_POST['address1']. "&productname=" .$_POST['productname'].  "&brand=" .$_POST["brand"]. "&size=" .$_POST["size"]. "&quantity=" .$_POST["quantity"]. "&address2="  .$_POST["address2"]);

}
    

  
  
?>